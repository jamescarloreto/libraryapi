import React, { useState } from 'react';
import { FaPlusCircle } from 'react-icons/fa';
import '../css/Books.css';
import BookCard from '../components/BookCard';
import Draggable from 'react-draggable';

const Books = () => {
  const [showPopup, setShowPopup] = useState(false);
  const [books, setBooks] = useState([
    { title: 'The Great Gatsby', author: 'F. Scott Fitzgerald', description: 'A classic novel set in the Jazz Age.' },
    { title: 'To Kill a Mockingbird', author: 'Harper Lee', description: 'A novel about racial injustice in the Deep South.' },
    { title: '1984', author: 'George Orwell', description: 'A dystopian novel about totalitarianism.' },
    { title: 'Moby Dick', author: 'Herman Melville', description: 'A story of Captain Ahab’s obsession with a giant whale.' },
    { title: 'Pride and Prejudice', author: 'Jane Austen', description: 'A romantic novel about manners and marriage in early 19th century England.' },
    { title: 'The Catcher in the Rye', author: 'J.D. Salinger', description: 'A story about teenage angst and rebellion.' }
  ]);

  const handleAddBook = () => {
    // This can be further developed to show a form to add a book
    console.log('Add Book button clicked');
  };

  const handleAddBookClick = () => {
    setShowPopup(true);
  };
  
  const handleClosePopup = () => {
    setShowPopup(false);
  };

  return (
    <div className="books-page">
      <h1 className="books-header">Books</h1>
      <div className="books-container">
        {books.map((book, index) => (
          <BookCard key={index} {...book} />
        ))}
      </div>
      <div className="floating-button">
        <button onClick={handleAddBook}>
          <FaPlusCircle size={50} />
        </button>
      </div>
      {showPopup && (
      <Draggable>
        <div className="add-book-popup">
          <button onClick={handleClosePopup} className="close-button">X</button>
          <form>
            <div className="form-group">
              <label>Title:</label>
              <input type="text" name="title" />
            </div>
            <div className="form-group">
              <label>Author:</label>
              <input type="text" name="author" />
            </div>
            <div className="form-group">
              <label>Description:</label>
              <textarea name="description"></textarea>
            </div>
            <button type="submit">Add Book</button>
          </form>
        </div>
      </Draggable>
    )}
    </div>
  );
};

export default Books;

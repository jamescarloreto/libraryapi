import React, { useState } from 'react';
import '../css/Library.css';
import { Button, Form, Container, Row, Col, Card } from 'react-bootstrap';
import Draggable from 'react-draggable';

const Library = () => {
  const [books, setBooks] = useState([
    { title: 'The Great Gatsby', author: 'F. Scott Fitzgerald', description: 'A classic novel set in the Jazz Age.' },
    { title: 'To Kill a Mockingbird', author: 'Harper Lee', description: 'A novel about racial injustice in the Deep South.' },
    { title: '1984', author: 'George Orwell', description: 'A dystopian novel about totalitarianism.' },
    { title: 'Moby Dick', author: 'Herman Melville', description: "A story of Captain Ahab's obsession with a giant whale." },
    { title: 'Pride and Prejudice', author: 'Jane Austen', description: 'A romantic novel about manners and marriage in early 19th century England.' },
    { title: 'The Catcher in the Rye', author: 'J.D. Salinger', description: 'A story about teenage angst and rebellion.' },
  ]);

  const [isAdding, setIsAdding] = useState(false);
  const [newBook, setNewBook] = useState({ title: '', author: '', description: '' });

  const handleAddClick = () => {
    setIsAdding(true);
  };

  const handleSaveClick = () => {
    setBooks([...books, newBook]);
    setNewBook({ title: '', author: '', description: '' });
    setIsAdding(false);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setNewBook({ ...newBook, [name]: value });
  };

  return (
    <Container className="library-container mt-4">
      <Row className="justify-content-center">
        <Col md={10}>
          <h2 className="text-center mb-4">Books</h2>
          <Row>
            {books.map((book, index) => (
              <Col md={4} key={index} className="mb-4">
                <Card>
                  <Card.Body>
                    <Card.Title>{book.title}</Card.Title>
                    <Card.Subtitle className="mb-2 text-muted">{book.author}</Card.Subtitle>
                    <Card.Text>{book.description}</Card.Text>
                  </Card.Body>
                </Card>
              </Col>
            ))}
          </Row>
          <div className="d-grid gap-2 mt-4">
            <Button variant="primary" onClick={handleAddClick}>Add Book</Button>
          </div>
        </Col>
      </Row>

      {isAdding && (
        <Draggable>
          <div className="add-book-popup">
            <Card>
              <Card.Body>
                <Card.Title className="text-center mb-4">Add a New Book</Card.Title>
                <Form>
                  <Form.Group className="mb-3">
                    <Form.Label>Title</Form.Label>
                    <Form.Control
                      type="text"
                      name="title"
                      value={newBook.title}
                      onChange={handleChange}
                    />
                  </Form.Group>
                  <Form.Group className="mb-3">
                    <Form.Label>Author</Form.Label>
                    <Form.Control
                      type="text"
                      name="author"
                      value={newBook.author}
                      onChange={handleChange}
                    />
                  </Form.Group>
                  <Form.Group className="mb-3">
                    <Form.Label>Description</Form.Label>
                    <Form.Control
                      as="textarea"
                      name="description"
                      value={newBook.description}
                      onChange={handleChange}
                    />
                  </Form.Group>
                  <div className="d-grid gap-2">
                    <Button variant="success" onClick={handleSaveClick}>Save Book</Button>
                  </div>
                </Form>
              </Card.Body>
            </Card>
          </div>
        </Draggable>
      )}
    </Container>
  );
};

export default Library;
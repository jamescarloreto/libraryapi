import React from 'react';
import { Container, Row, Col, Button } from 'react-bootstrap';
import '../css/Home.css';

const Home = () => {
  return (
    <Container className="home-container mt-5">
      <Row className="justify-content-center text-center">
        <Col md={8} lg={6}>
          <h1 className="mb-4">Welcome to the Document Management System</h1>
          <p className="lead">Manage your documents efficiently and effortlessly.</p>
        </Col>
      </Row>
      <Row className="justify-content-center mt-4">
        <Col xs="auto">
          <Button variant="primary" className="me-3">Browse Books</Button>
          <Button variant="outline-secondary">Admin Panel</Button>
        </Col>
      </Row>
    </Container>
  );
};

export default Home;

import React from 'react';
import '../css/Admin.css';

const AdminPanel = () => {
  return (
    <div className="admin-container">
      <h2 className="admin-title">Admin Panel</h2>
      <form className="admin-form">
        <input type="text" placeholder="Enter title" />
        <textarea placeholder="Enter description"></textarea>
        <button type="submit">Add Document</button>
      </form>
    </div>
  );
};

export default AdminPanel;

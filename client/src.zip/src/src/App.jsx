import React, { useState } from 'react';
import { Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import Books from './pages/Books';
import AdminPanel from './pages/AdminPanel';
import Profile from './pages/Profile';
import Login from './components/Login';
import Main from './layout/Main';

const App = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const handleLogin = () => {
    setIsAuthenticated(true);
  };

  return (
    <>
      {isAuthenticated ? (
        <>
          <Main />
          {/* Render Routes */}
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/books" element={<Books />} />
            <Route path="/admin" element={<AdminPanel />} />
            <Route path="/profile" element={<Profile />} />
          </Routes>
        </>
      ) : (
        <Login onLogin={handleLogin} />
      )}
    </>
  );
};

export default App;

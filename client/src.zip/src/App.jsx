
import React, { useEffect, useState } from 'react';
import { fetchBooks, addBook, updateBook, deleteBook } from './utils/axios';

const App = () => {
    const [books, setBooks] = useState([]);
    const [newBook, setNewBook] = useState({ title: '', author: '', description: '' });

    // Fetch books from the database
    const loadBooks = async () => {
        const data = await fetchBooks();
        setBooks(data);
    };

    useEffect(() => {
        loadBooks(); // Fetch books on component mount
    }, []);

    const handleAddBook = async () => {
        await addBook(newBook); // Add book directly to the database
        setNewBook({ title: '', author: '', description: '' });
        loadBooks(); // Refresh books from the database
    };

    const handleUpdateBook = async (id) => {
        await updateBook(id, { title: 'Updated Title' }); // Update book in the database
        loadBooks(); // Refresh books from the database
    };

    const handleDeleteBook = async (id) => {
        await deleteBook(id); // Delete book from the database
        loadBooks(); // Refresh books from the database
    };

    return (
        <div>
            <h1>Books</h1>
            <div>
                {books.map((book) => (
                    <div key={book._id} style={{ border: '1px solid black', margin: '10px', padding: '10px' }}>
                        <h2>{book.title}</h2>
                        <p>{book.author}</p>
                        <p>{book.description}</p>
                        <button onClick={() => handleDeleteBook(book._id)}>Delete</button>
                        <button onClick={() => handleUpdateBook(book._id)}>Update</button>
                    </div>
                ))}
            </div>
            <div>
                <h2>Add New Book</h2>
                <input
                    type="text"
                    placeholder="Title"
                    value={newBook.title}
                    onChange={(e) => setNewBook({ ...newBook, title: e.target.value })}
                />
                <input
                    type="text"
                    placeholder="Author"
                    value={newBook.author}
                    onChange={(e) => setNewBook({ ...newBook, author: e.target.value })}
                />
                <input
                    type="text"
                    placeholder="Description"
                    value={newBook.description}
                    onChange={(e) => setNewBook({ ...newBook, description: e.target.value })}
                />
                <button onClick={handleAddBook}>Add Book</button>
            </div>
        </div>
    );
};

export default App;
